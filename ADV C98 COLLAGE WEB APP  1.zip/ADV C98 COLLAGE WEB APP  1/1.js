var SpeechRecognition = window.webkitSpeechRecognition;

var recog = new SpeechRecognition();

function save() {
    document.getElementById("textbox").innerHTML = "";
    recog.save();
}

recog.onresult = function(event) {
    console.log(event);

    var text = event.results[0][0].transcript;

    document.getElementById("textbox").innerHTML = text;

    console.log(text);
} 